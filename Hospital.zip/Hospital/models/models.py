from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_manager, UserMixin, AnonymousUserMixin, current_user 
from flask_admin.contrib.sqla import ModelView
from flask import abort
from datetime import datetime


db = SQLAlchemy()
login_manager = LoginManager()



class User(UserMixin, db.Model):
    
    id = db.Column(db.Integer,primary_key=True)
    first_name = db.Column(db.String(255), index=True)
    last_name = db.Column(db.String(255), index=True)
    username = db.Column(db.String(60), index=True, unique=True)
    age = db.Column(db.Integer)
    marital_status = db.Column(db.String(255), index=True)
    gender = db.Column(db.String(255), index=True)
    email = db.Column(db.String(60), index=True, unique=True)
    phone_number = db.Column(db.Integer)
    password_hash = db.Column(db.String(128))
    registed_at = db.Column(db.String(20),default=datetime.now())
    confirm_at = db.Column(db.String(20),default=datetime.now())
    confirm = db.Column(db.Boolean,default=False)
    is_admin = db.Column(db.Boolean, default=False)

    @property
    def password(self):
        """
        Prevent pasword from being accessed
        """
        raise AttributeError('password is not a readable attribute.')

    @password.setter
    def password(self, password):
        """
        Set password to a hashed password
        """
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        """
        Check if hashed password matches actual password
        """
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return '<User: {}>'.format(self.username)


# Set up user_loader
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class login(db.Model,UserMixin):
    id = db.Column(db.Integer,primary_key=True)
    email = db.Column(db.String(255),unique=True)
    password = db.Column(db.String(255))



class Appointment_booked(db.Model,UserMixin):
    
    id = db.Column(db.Integer,primary_key=True)
    full_name = db.Column(db.String(255))
    email = db.Column(db.String(255),unique=True)
    phone_number = db.Column(db.Integer)
    date = db.Column(db.String(225))
    time = db.Column(db.String(225))
    state = db.Column(db.String(225))
    hospital = db.Column(db.String(225))    
    message = db.Column(db.String(450))



class ViewsControl(ModelView):
    def is_accessible(self):
        try:
            if current_user.is_authenticated and current_user.is_admin == True:
                return current_user.is_authenticated
            else:
                return abort(404)
        except AttributeError:
            return 'error'


class Temp(db.Model):
    
    id = db.Column(db.Integer,primary_key=True)
    signature = db.Column(db.String(255))
    email = db.Column(db.String(255))


class Otp(db.Model):
    
    id = db.Column(db.Integer,primary_key=True)
    signature = db.Column(db.String(255))
    phone_number = db.Column(db.String(255))
