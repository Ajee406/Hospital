from flask import flash, abort, Blueprint, render_template, request, redirect, url_for
from flask_login import current_user, login_required
from models.models import * 
from . import home



@home.route('/')
def homepage():
    
    return render_template('home/index.html', title="Welcome")


@home.route('/dashboard')
@login_required
def dashboard():
    
    return render_template('home/dashboard.html', title="Dashboard")


@home.route('/admin/dashboard')
@login_required
def admin_dashboard():
    # prevent non-admins from accessing the page
    if not current_user.is_admin:
        abort(403)

    return render_template('home/admin_dashboard.html', title="Dashboard")




@home.route('/Profile')
@login_required
def Profile():
    users = User.query.all()
    return render_template('/base.html',users=users)



@home.route('/migrate')
def migrate():
    db.drop_all()
    db.create_all()
    return "database dropped"
