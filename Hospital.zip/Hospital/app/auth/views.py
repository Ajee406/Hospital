from flask import flash, Blueprint, redirect, render_template, request, url_for
from flask_login import login_required, current_user,  login_user, logout_user, LoginManager, login_manager
from . import auth
from .. import db
from models.models import *
from .forms import LoginForm, Confirm_appointmentForm
from flask_mail import Mail, Message
from sqlalchemy.exc import  IntegrityError
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
import random
from twilio.rest import Client


s = URLSafeTimedSerializer('hkjdsfhkjfdhksfhsdkhfk')
mail = Mail()



@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            first_name = request.form['first_name']
            last_name = request.form['last_name']
            username = request.form['username']
            age = request.form['age']
            marital_status = request.form['marital_status']
            gender = request.form['gender']
            email = request.form['email']
            phone_number = request.form['phone_number']
            password = request.form['pass']
            hashed_password = generate_password_hash(password,method='sha256')
            
            token = s.dumps(email,salt='email_confirm')
            link = url_for('auth.confirm_email',token=token, _external=True)
            
            
            msg = Message('Welcome',sender='admin@programmer.com',recipients=[email]) #calling Messge
            msg.body="Welcome to OpenTekMedical.com, please click this link to confirm email "+link
            mail.send(msg)

            new_temp_data = Temp(signature=token,email=email)
            member = User(first_name=first_name,
                                last_name=last_name,
                                username=username,
                                age=age,
                                marital_status=marital_status,
                                gender=gender,
                                email=email,
                                phone_number=phone_number,
                                password=password)
               
            db.session.add(member)    # add member to the database
            db.session.add(new_temp_data)
            db.session.commit()
            flash('You have successfully registered! You may now login.')
            return redirect(url_for('auth.login')) # redirect to the login page

        except IntegrityError:
            flash("User already exist")
            return redirect(url_for('auth.register'))
        except Exception as e :
            print(e)
            flash("Something went wrong!!!")
            return redirect(url_for('auth.register'))
    
    return render_template('auth/register.html', title='Register') # load registration template


@auth.route('/confirm_email/<token>')
def confirm_email(token):
    try:
        saved_copy = Temp.query.filter_by(signature=token).first()
        if saved_copy:
            email = s.loads(token,salt='email_confirm',max_age=6000)
            user = User.query.filter_by(email=saved_copy.email).first()
            user.confirm = True   
            db.session.commit()
            saved_copy = Temp.query.filter_by(signature=token).delete()
            db.session.commit()
            flash ('your email has been confirmed')
            return redirect(url_for('auth.login'))
        else:
            return 'unathorizd signature submitted'
    except SignatureExpired:
        return '<h2>The token is expired!!! please go to the platform and open another account</h2>'


@auth.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():

        # check whether member exists in the database and whether
        # the password entered matches the password in the database
        member = User.query.filter_by(email=form.email.data).first()
        if member is not None and member.verify_password(
                form.password.data):
            # log memberin
            login_user(member)

            # redirect to the appropriate dashboard page
            if member.is_admin:
                return redirect(url_for('home.admin_dashboard'))
            else:
                return redirect(url_for('home.dashboard'))

        # when login details are incorrect
        else:
            flash('Invalid email or password.')

    # load login template
    return render_template('auth/login.html', form=form, title='Login')


@auth.route('/forgot_password',methods=['GET','POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        user = User.query.filter_by(email=email).first()
        if user:
            if user.confirm:
                token = str(random.randint(3333,4444))
                msg = Message('Forgot pasword',sender='admin@programmer.com',recipients=[email]) #calling Messge
                msg.body="Please use this code to verify your account          "+token
                mail.send(msg)
                new_temp_data = Temp(signature=token,email=email)
                db.session.add(new_temp_data)
                db.session.commit()
                flash ('Insert the code sent to your mail into the code area')
                return redirect(url_for('auth.change_password'))
            else:
                flash ('you have not confirm your email, please click the link sent to your email address before you can change your password')
                return redirect(url_for('auth.login'))
        else:
            flash ('invalid email')
            return redirect(url_for('auth.login'))

    return render_template('./auth/forgot_password.html')



@auth.route('/change_password',methods=['GET','POST'])
def change_password():
    if request.method =='POST':
        code = request.form['code']
        password = request.form['password']
        check_code = Temp.query.filter_by(signature=code).first()
        if check_code:
            user = User.query.filter_by(email=check_code.email).first()
            if user:
                user.password = hashed_password = generate_password_hash(password,method='sha256')

                db.session.commit()
                flash('password changed')
                return redirect(url_for('auth.login'))

            else:
                flash('invalid user 419')
                return redirect(url_for('auth.register'))
        else:
            flash('you are a computer hacker !!!')
            return redirect(url_for('auth.register'))

    return render_template('./auth/change_password.html')  



@auth.route('/appointment',methods=['GET','POST'])
@login_required
def appointment():
    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        phone_number = request.form['phone_number']
        date=request.form['date']
        time = request.form['time']
        state = request.form['state']
        hospital = request.form['hospital']
        message = request.form['message']
                      
        
        book_appointment = Appointment_booked(full_name=full_name,
                                        email=email,
                                        phone_number=phone_number,
                                        date=date,
                                        time=time,
                                        state=state,
                                        hospital=hospital,
                                        message=message)
        
        account_sid = "AC4a987dc473b61705fd5114ffaa707ec1"        # Your Account SID from twilio.com/console
        auth_token  = "0f8863714abeba62cb540707c7514e34"
        client = Client(account_sid, auth_token)

        message = client.messages.create(
            to="+2348039267621", 
            from_="+19166192142",
            body = 'This is your token   ' + str(random.randrange(100000, 999999)))
            
        db.session.add(book_appointment)
        db.session.commit()
        print(message.sid)
        flash('Thank You for Using Our Platform.....')
        
        return redirect(url_for('home.dashboard'))
        
            
    return render_template('./auth/appointments.html')


@auth.route('/confirm_apoint', methods=['GET', 'POST'])
def confirm_apoint():
    form = Confirm_appointmentForm()
    
    return render_template('auth/confirm_apoint.html', form=form, title='Login')



@auth.route('/permission')
def permission():
    current_user.is_admin = False
    db.session.commit()
    return 'account upgraded'


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have successfully been logged out.')

    # redirect to the login page
    return redirect(url_for('auth.login'))
