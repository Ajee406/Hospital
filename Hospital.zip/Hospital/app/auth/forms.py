from flask_wtf import FlaskForm
from wtforms import PasswordField, StringField, SubmitField, ValidationError
from wtforms.validators import DataRequired, Email, EqualTo

from models.models import *


    

class LoginForm(FlaskForm):
    """
    Form for users to login
    """
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')
    

class Confirm_appointmentForm(FlaskForm):
    """
    Form for Appointment Booking
    """
    token = StringField('Token', validators=[DataRequired()])    
    submit = SubmitField('Submit')
