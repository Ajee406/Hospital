SECRET_KEY='fdhjgjhjsdfhjdgjgdjdf'
SQLALCHEMY_TRACK_MODIFICATIONS=True
SQLALCHEMY_DATABASE_URI = 'sqlite:///Hospital.db'


MAIL_SERVER='smtp.gmail.com'
MAIL_USERNAME='ajeeahmed4@gmail.com'  # allows the emails u put here to be sending confirmation messages to people that sign up in you site
MAIL_PASSWORD='Aji419911'
MAIL_DEFAULT_SENDER = 'OpenTekMedicals.com'
MAIL_PORT=465
MAIL_USE_SSL=True
MAIL_USE_TLS=False
